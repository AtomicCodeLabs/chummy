export * as vanillaLight from '../../themes/vanilla.light.json';
export * as vanillaDark from '../../themes/vanilla.dark.json';
export * as monokaiDark from '../../themes/monokai.dark.json';
export * as materialLight from '../../themes/material.light.json';
export * as materialDark from '../../themes/material.dark.json';
export * as onedarkDark from '../../themes/onedark.dark.json';
export * as janesThemeLight from '../../themes/janestheme.light.json';
export * as draculaDark from '../../themes/dracula.dark.json';
