export const GITHUB_COLOR = '#211F1F';

export const WHITE = '#FFFFFF';

export const BLACK = '#000000';
