import { createContext } from 'react';
import rootStore from './root.store';

export default createContext(rootStore);
